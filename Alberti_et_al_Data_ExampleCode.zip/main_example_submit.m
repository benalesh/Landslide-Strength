clear all

%inputs
headscarp_polygon_shapefile='C:/path/Elk_City_303.shp'; %Path for headscarp Polygon
shape_path='C:/path/';                                  %Path for deposit polygon                             
DEMraster_paths='C:/path/';                             %Path for clipped DEM
DEMname='Elk_City_303';                                 %Name of DEM file
shapefilename='Deposits_ELK';                           %Name of Shapefile
savefilename='test.mat';                                %Name of output file to be saved
root_toggle=1;                                          %toggle for root cohesion, 1 is yes
root_strength=0;                                        %lateral cohesion of roots, psf
root_depth=1.5;                                         %root depth, feet  
gw=0;                                                   %groundwater depth, feet
run_stability=1;                                        %do back-analysis, 1 is yes

%Processing
cellsize=10/3;                                          %cell size, feet
reg=0.86;                                               %regularization coeff.
phi_steps=5;                                            %range of c an phi values calculated


%Load Relevant Shapefile Data
i=1;
ii=1;
idx=356;
disp(strcat('Loading...',shapefilename));
flanks=shaperead(headscarp_polygon_shapefile);
deps=shaperead(strcat(shape_path,shapefilename,'.shp'));
flanksX=flanks.X;
flanksY=flanks.Y;
flanksX=flanksX(~isnan(flanksX));
flanksY=flanksY(~isnan(flanksY));
depsX=deps(idx).X;
depsY=deps(idx).Y;
depsX=depsX(~isnan(depsX));
depsY=depsY(~isnan(depsY));
farea=polyarea(flanksX,flanksY);
deparea=polyarea(depsX,depsY)-farea;
totalarea=deparea+farea;

disp('Load Complete.'); warning('off','all');
toc

%Load Associated Raster Data and Booleans
[dem_norec,R]=readgeoraster(strcat(DEMraster_paths,DEMname,'.tif'));
dem_norec(abs(dem_norec)>1e4)=NaN; %assign NaN to No Data cells
rs=20/cellsize;
dem_norec=imresize(dem_norec,rs);   

[m,n]=size(dem_norec);
x=(0:cellsize:cellsize*(n-1))+R.XWorldLimits(1,1);
y=(cellsize*(m-1):-cellsize:0)+R.YWorldLimits(1,1);
[X,Y]=meshgrid(x,y);

% dem_bool1=inpolygon(X,Y,deps(idx).X,deps(idx).Y); %deposit+flanks
dem_bool1=inpolygon(X,Y,flanksX,flanksY); %deposit+flanks
dem_bool2=inpolygon(X,Y,flanksX,flanksY)-dem_bool1; %flanks
dem_bool=dem_bool1+dem_bool2;

dem_bool1(dem_bool1>0)=1;
dem_bool1(dem_bool1<1)=0;
dem_bool2(dem_bool2>0)=1;
dem_bool2(dem_bool2<1)=0;
dem_bool(dem_bool>0)=1;
dem_bool(dem_bool<1)=0;   
bool_dep=dem_bool1-dem_bool2; 
bool_dep(bool_dep<0)=0;

%Get Curvature, reconsructed surface, and booleans

    [dem_ss,dem_inp]=get_surfaces(X,Y,dem_norec,dem_bool1,bool_dep,cellsize,depsX,depsY,flanksX,flanksY,reg);
        
    id=find(dem_inp-dem_ss>0);
    recvol=mean(dem_inp(id)-dem_ss(id),'all')./3.28;
    arec=length(id).*cellsize.*cellsize./(3.28^2);
    id=find(dem_norec-dem_ss>0);
    norecvol=mean(dem_norec(id)-dem_ss(id),'all')./3.28;
    anorec=length(id).*cellsize.*cellsize./(3.28^2);
    
    %Get Deposit Curvature (not reconsructed)
    [profc,planc] = curvature(dem_norec,cellsize,'both');
    mean_prof_curv_norec=nanmean(profc(dem_bool==1),'all');
    mean_plan_curv_norec=nanmean(planc(dem_bool==1),'all');
    shape_output.profc_norec(i,1)=mean_prof_curv_norec;
    shape_output.planc_norec(i,1)=mean_plan_curv_norec;

    median_prof_curv_norec=nanmedian(profc(dem_bool==1),'all');
    median_plan_curv_norec=nanmedian(planc(dem_bool==1),'all');
    shape_output.profc_norec_med(i,1)=median_prof_curv_norec;
    shape_output.planc_norec_med(i,1)=median_plan_curv_norec;    
    
    %Get Deposit Curvature (reconstructed)
    [profc,planc] = curvature(dem_inp,cellsize,'both');
    mean_prof_curv_rec=nanmean(profc(dem_bool1==1),'all');
    mean_plan_curv_rec=nanmean(planc(dem_bool1==1),'all');
    shape_output.profc_rec(i,1)=mean_prof_curv_rec;
    shape_output.planc_rec(i,1)=mean_plan_curv_rec;
    
    shape_output.area_deps_and_scarp(i,1)=sum(dem_bool1,'all');
    shape_output.area_deps(i,1)=sum(dem_bool,'all'); 
    
    vol_rc_differencing=(dem_inp-dem_ss).*dem_bool;
    vol_rc_differencing(vol_rc_differencing<0)=NaN;
    vol_norc_differencing=(dem_norec-dem_ss).*dem_bool1;
    vol_norc_differencing(vol_norc_differencing<0)=NaN;   
    
    overlap_deps_scar=sign(vol_rc_differencing)+dem_bool1;
    tot_area_deps_scar=dem_bool1;
    overlap_deps_scar(overlap_deps_scar<2)=0;
    overlap_deps_scar(overlap_deps_scar==2)=1;
       
    %overlap between scar and deposit proportional to toal landslide area
    overlap_deps_scar=sign(vol_norc_differencing)+sign(vol_rc_differencing);
    overlap_deps_scar(overlap_deps_scar<2)=NaN;
    overlap_deps_scar(overlap_deps_scar==2)=1;
    overlap_total_area=sign(vol_norc_differencing)+sign(vol_rc_differencing);
    overlap_total_area(overlap_total_area>0)=1;
   
    shape_output.overlap_deps_scar(i,1)=sum(overlap_deps_scar,'all','omitnan')./sum(overlap_total_area,'all','omitnan');
    
    norec_real=sum(sign(vol_rc_differencing),'all','omitnan');
    rec_real=sum(sign(vol_norc_differencing),'all','omitnan');
    
 
if run_stability==1 %&& ~isnan(norec_real) && norec_real>0 && ~isnan(rec_real) && rec_real>0 
    
    gs=127; %unit weight of soil/rock [pcf]
    
    %Get Gradients
    [Slope,Aspect,~,~] = gradient_king(dem_ss,cellsize);
    [SlopeSurf,~,~,~] = gradient_king(dem_norec,cellsize);
        
    
    %Friction angle of Deposits    
    temp_bool=sign(vol_norc_differencing);

        temp_bool(isnan(temp_bool))=0;
        type='phi';
        
        root_reinforcement=0;
        phi_guess=0;
        c_guess=0;
        iter_lim=1000;
        thick=mean(vol_norc_differencing(temp_bool>0));
        
        [phif,~,rotf,thickf,areaf,volf,slopef,medslopef,slopessf,uf,iter,ppf,cpf]=back_analysis_v4(dem_norec,dem_ss,temp_bool,cellsize,type,phi_guess,c_guess,gs,thick,gw,iter_lim,root_reinforcement,root_strength,root_depth,Slope,Aspect,SlopeSurf);
        
        phi_dep(i,1)=phif;
        thick_dep(i,1)=thickf;
        area_dep(i,1)=areaf;
        vol_dep(i,1)=volf;
        slope_dep(i,1)=slopef;
        slope_median_dep(i,1)=medslopef;
        slope_ss_dep(i,1)=slopessf;
        u_dep(i,1)=uf;
        iter_dep(i,1)=iter;
    
     %Friction Angle of Scars
        temp_bool=sign(vol_rc_differencing);
        temp_bool(isnan(temp_bool))=0;
        type='phi';

        root_reinforcement=root_toggle; 
        phi_guess=0;
        c_guess=0;
        iter_lim=1000;
        thick=mean(vol_rc_differencing(temp_bool>0));
        
        [SlopeSurf,~,~,~] = gradient_king(dem_inp,cellsize);
        
        [phif,~,rotf,thickf,areaf,volf,slopef,medslopef,slopessf,uf,iter,ppf,cpf]=back_analysis_v4(dem_inp,dem_ss,temp_bool,cellsize,type,phi_guess,c_guess,gs,thick,gw,iter_lim,root_reinforcement,root_strength,root_depth,Slope,Aspect,SlopeSurf);        
        
        phi_scar(i,1)=phif;
        thick_scar(i,1)=thickf;
        area_scar(i,1)=areaf;
        vol_scar(i,1)=volf;
        slope_scar(i,1)=slopef;
        slope_median_scar(i,1)=medslopef;
        slope_ss_scar(i,1)=slopessf;
        u_scar(i,1)=uf;
        iter_scar(i,1)=iter;
        
      %Cohesion range of scar
       cguess=0;
       cf=0;
      phi_i=linspace(phi_scar(i,1),0,phi_steps);
      for j=2:length(phi_i)
          
        root_reinforcement=root_toggle;   
        type='c';
        phi_guess=phi_i(j);
        
     [phif,cf,rotf,thickf,areaf,volf,slopef,medslopef,slopessf,uf,iter,ppf,cpf]=back_analysis_v4(dem_inp,dem_ss,temp_bool,cellsize,type,phi_guess,c_guess,gs,thick,gw,iter_lim,root_reinforcement,root_strength,root_depth,Slope,Aspect,SlopeSurf);       
        
     coh_scar_range(i,j)=cf;
     phi_scar_range(i,j)=phif;
     phi_prop_range(i,j)=ppf;
     c_prop_range(i,j)=cpf;
     
     iter_scar(i,j)=iter;
     c_guess=cf;
     
      end
     
      
     
     phi_prop_range(i,1)=1;
     phi_scar_range(i,1)=phi_scar(i,1);
     bulk_BA(i,1)=vol_dep(i,1)./vol_scar(i,1);
    
     
     %Outputs, corrected to Metric
     
     
        %STRENGTH OUTPUTS
        phi_dep(i,1)=phi_dep(i,1); %friction angle of deposit in equilibrium (no cohesion)
        phi_scar(i,1)=phi_scar(i,1); %requisite friction angle of source (no cohesion)
        coh_scar(i,1)=interp1(phi_scar_range(i,:),coh_scar_range(i,:),phi_dep(i)); %inferred cohesion from source based on deposit friction angle [kPa]
        
        %SCAR OUTPUTS
        thick_scar(i,1)=thick_scar(i,1)./3.28; %mean source landslide thickness [m];
        area_scar(i,1)=area_scar(i,1)./3.28./3.28; %source landslide area [m^2];
        vol_scar(i,1)=vol_scar(i,1)./3.28./3.28./3.28; %source landslide area [m^3];
        slope_scar(i,1)=slope_scar(i,1); %mean source landslide inclination [°];

        %DEPOSIT OUTPUTS
        thick_dep(i,1)=thick_dep(i,1)./3.28; %mean source landslide thickness [m];
        area_dep(i,1)=area_dep(i,1)./3.28./3.28; %source landslide area [m^2];
        vol_dep(i,1)=vol_dep(i,1)./3.28./3.28./3.28; %source landslide area [m^3];
        slope_dep(i,1)=slope_dep(i,1); %mean source landslide inclination [°];       
        
        %MECHANISM AND BULKING
        mechanism{i,1}=deps(idx,1).MOVE_CLASS;
        bulk(i,1)=bulk_BA(i,1);
        
end





    
    
    
    
    









