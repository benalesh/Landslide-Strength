 %% Loop 1: Rotate failure direction
% Do so until the sum of transverse forces crosses 0
function [rot, phif, cf, iter, ppf,cpf] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp, c0, phi0, W0, u, gs, strength, kx, ky, Ex, Ey, c_inc, iter_lim, root_cohesion,root_depth)

Aspect(isnan(Aspect))=0;
Slope(isnan(Slope))=0;

            cpf = NaN;
            ppf = NaN;
% Specify initial parameters
if strcmp(strength,'phi')==1
    st = 1;
else
    st = 2;
end
% Choose the rotation and phi increments - smaller values equal more exact
% solutions, but longer computation times
asp_inc = 2; %1
phi_inc = 1;

W = W0.*gs.*csize.*csize;

%apply root cohesion (if applicable)
root_idx=find(W0<=root_depth);
croot=zeros(size(W0));
croot(root_idx)=croot(root_idx)+root_cohesion;


asp_shift = 0;% Rotation of failure surface from mean aspect
%               0 means that failure direction equals mean aspect
%               Clockwise is positive
switchA = 0;% 0 means sum of transverse forces has not been positive
switchB = 0;% 0 means sum of transverse forces has not been negative
% Only once both positive and negative sums have been achieved does
% switchA*switchB = 0, and the looping stops.

iter2 = 0;

inc = 1;% FILL IN
ias = 1;% FILL IN
asp0 = asp;% Record initial aspect so that asp may be manipulated
while switchA*switchB == 0

    % Apply aspect shift to aspect (0 for attempt 1)
    asp = asp0+asp_shift;
    % Project slope vectors into longitudinal (failure
    % direction) and transverse directions - simple dot product
    dlon = Aspect-asp;% Difference between each pixel's aspect
                      % and the longitudinal direction
    dtra = (Aspect+90)-asp;% Difference between each pixel's
                      % aspect and the transverse direction
    dy = Slope.*cosd(dlon);% longitudinal pixel slopes
    dx = Slope.*cosd(dtra);% transverse pixel slopes
    
    %% Introduced by Stefano
    %dy(isnan(dy))=0; % by Stefano 02/08/2021
    %dx(isnan(dx))=0; % by Stefano 02/08/2021

    %% Compute basic geometric properties of each column
    % Compute area of column's true base
    Atb = mask_red.*(csize).*(csize).*sqrt(1-sind(dx).^2.*sind(dy).^2)./(cosd(dx).*cosd(dy));

    % Compute local dip of sliding surface
    gz = sqrt(1./(tand(dy).^2+tand(dx).^2+1));

    % Loop 2: Increase phi until FS passes 1.0
    phi = phi0;        % Start with phi = 1
    c = c0;%*ones(size(W0));
    FSy = 1;
    FRy = 0;
    FDy = 1;
    iter = 0;
    
    %c(W0==0)=0;
    
    while FRy<FDy && iter<iter_lim
        if st == 1
            phi = phi+phi_inc;
        else
            c = c+c_inc;
        end
        iter = iter+1;
      
               
        %% Compute LONGITUDINAL stability
        % Compute normal force at base of column (Assume FS = 1)
        md = gz.*(1+(sind(dy).*tand(phi))./(FSy.*gz));
        %N = (W-c.*Atb.*sind(dy)./FSy+u.*Atb.*tand(phi).*sind(dy)./FSy)./md;
        N = (W-(c+croot).*Atb.*sind(dy)./FSy+u.*Atb.*tand(phi).*sind(dy)./FSy)./md;
        
        
        
        % Compute FS
        term1 = (c+croot).*Atb.*gz+(N-u.*Atb).*tand(phi).*cosd(dy);
        term2 = N.*gz.*tand(dy);
        term3 = ky.*W+Ey;
        sum_t1 = sum(term1); sum_t2 = sum(term2); sum_t3 = sum(term3);

        %Proportional Strength
        c_prop=sum(c.*Atb.*gz)./sum(term1);
        phi_prop=sum((N-u.*Atb).*tand(phi).*cosd(dy))./sum(term1);
        
        FRy = sum_t1;
        FDy = sum_t2+sum_t3;

        FSY(iter) = sum_t1/(sum_t2+sum_t3);
        ITER(iter) = iter;
        FRY(iter) = FRy;
        FDY(iter) = FDy;
        
        if st == 1
            PHI(iter) = phi;
            CP(iter)=c_prop;
            PP(iter)=phi_prop;
            
        else
            C(iter) = c;
            CP(iter)=c_prop;
            PP(iter)=phi_prop;
        end

        % Identify correct factor of safety
        FSx1 = 100; %100
        mdx = gz.*(1+(sind(dx).*tand(phi))./(FSx1.*gz));
        Nx = (W-(c+croot).*Atb.*sind(dx)./FSx1+u.*Atb.*tand(phi).*sind(dx)./FSx1)./mdx;
        term1x = (c+croot).*Atb.*gz+(Nx-u.*Atb).*tand(phi).*cosd(dx);
        term2x = N.*gz.*tand(dx);
        term3x = kx.*W+Ex;
        sum_t2x = sum(term2x); sum_t3x = sum(term3x);
        FSx2 = sum(term1x)/(sum_t2x+sum_t3x);

        % Run equation again to obtain driving forces at correct FS
        mdx = gz.*(1+(sind(dx).*tand(phi))./(FSx2.*gz));
        Nx = (W-(c+croot).*Atb.*sind(dx)./FSx2+u.*Atb.*tand(phi).*sind(dx)./FSx2)./mdx;
        term1x = (c+croot).*Atb.*gz+(Nx-u.*Atb).*tand(phi).*cosd(dx);
        term2x = N.*gz.*tand(dx);
        term3x = kx.*W+Ex;
        sum_t2x = sum(term2x); sum_t3x = sum(term3x);
        FRx = sum(term1x);
        FDx = sum_t2x+sum_t3x;
        
        if isnan(c) || isnan(phi)
            phif = NaN;
            cf = NaN;   
            rot=NaN;
            iter=NaN;
            return
            
        end
        
    end
    if iter > 1
        xi = [FSY(iter-1) FSY(iter)];
        cpi =[CP(iter-1) CP(iter)];
        ppi =[PP(iter-1) PP(iter)];
        %if st == 1 
        if st == 1 && isnan(sum(xi))==0
            vi = [PHI(iter-1) PHI(iter)];
            
            phif = interp1(xi,vi,1);
            cf = c;
            
            cpf = interp1(xi,cpi,1);
            ppf = interp1(xi,ppi,1);

            
        elseif xi(1)-xi(2)==0 || isnan(sum(xi))
            phif = NaN;
            cf = NaN;   
            rot=NaN;
            cpf = NaN;
            ppf = NaN;
            return
        %else
        elseif st == 2 && isnan(sum(xi))==0
            vi = [C(iter-1) C(iter)];
            cf = interp1(xi,vi,1);
            phif = phi;
            cpf = interp1(xi,cpi,1);
            ppf = interp1(xi,ppi,1);
        
        end
        xi = []; vi = [];
        
    elseif iter==iter_lim-1 
            phif = NaN;
            cf = NaN;   
            rot=NaN;
            cpf = NaN;
            ppf = NaN;
            return
    else
        if st == 1
            phif = PHI(iter)-phi_inc;
            cf = c;
        else
            cf = C(iter)-c_inc;
            phif = phi;
        end
    end

    iter2 = iter2+1;
    FRX(iter2) = FRx;
    FDX(iter2) = FDx;
    FS1(iter2) = FSx1;
    FS2(iter2) = FSx2;
    ITER2(iter2) = iter2;
    ROT(iter2) = asp_shift;

    if FDx>0
        switchA = 1;
    else
        switchB = 1;
    end
    if iter2 == 2
        if abs(FDX(1))<abs(FDX(2))
            ias = -1;
        end
    end
    asp_shift = asp_shift+ias*asp_inc;

end
if iter2 > 1
    xi = [FDX(iter2-1) FDX(iter2)];
    vi = [ROT(iter2-1) ROT(iter2)];
    
    if xi(1)-xi(2)==0 || vi(1)-vi(2)==0 || isnan(sum(xi)) || isnan(sum(vi)) || isinf(sum(xi)) || isinf(sum(vi)) 
            phif = NaN;
            cf = NaN;   
            rot=NaN;
            cpf = NaN;
            ppf = NaN;
            return
    else
    rot = interp1(xi,vi,0);
    xi = []; vi = [];
    end
else
    rot = ROT(iter2);
end

% asp_shift = asp_shift-ias*asp_inc;
% table(phif,cf,rot)