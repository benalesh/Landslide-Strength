function [dem_ss,dem_rec]=get_surfaces(X,Y,dem_norec,dem_bool1,bool_dep,cellsize,depsX,depsY,flanksX,flanksY,reg)


    %Slip Surface
    dem_ss=dem_norec;
    
    %Get boundary constraints
    bring=dem_bool1;
    bring=bwmorph(bring,'thicken',1)-bring;
    bscarp=dem_bool1-bool_dep;
    bscarp=bwmorph(bscarp,'thicken',1)-bscarp;
    bring=bring+bscarp;
    bring(bring>1)=1;
    bring(bring<0)=0;
    brt=bring(:);
    Xt=X(:); Xt=Xt(brt==1);
    Yt=Y(:); Yt=Yt(brt==1);
    Zt=dem_norec(:); Zt=Zt(brt==1);


    verts=vertcat(horzcat(depsX,flanksX),horzcat(depsY,flanksY));
    vertz=interp2(X,Y,dem_norec,horzcat(depsX,flanksX),horzcat(depsY,flanksY)); 
    
    %Thin plate spline
     [st] = tpaps(verts,vertz,reg);

    idx=find(bool_dep==1);
    xi=X(idx);
    yi=Y(idx);
    
    avals = fnval(st,vertcat(xi',yi'));

    dem_ss(idx)=avals;
    

    
    %Reconstructed Surface
    
        Ztemp=dem_norec;
    Ztemp(isnan(Ztemp))=0;
    
    tbool=dem_bool1;
    tbool=bwmorph(tbool,'thicken',1);
    Ztemp(tbool==1)=NaN;
    
    [dem_rec]=inpaint_nans(double(Ztemp),0); %inpaint reconstructed surface 
    dem_rec(dem_bool1==0)=dem_rec(dem_bool1==0);
    dem_rec(dem_rec==0)=NaN;
    
    
out=111;