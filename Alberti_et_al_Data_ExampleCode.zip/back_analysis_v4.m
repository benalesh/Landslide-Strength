function [phif,cf,rotf,thickf,areaf,volf,slopef,medslopef,slopessf,uf,iter,ppf,cpf]=back_analysis(dem,dem_ss,bool,cellsize,strength,phi_guess,c_guess,gs,thick,gwdepth,iter_lim,root_reinforcement,root_val,root_depth,Slope,Aspect,SlopeSurf)



%cohesion and friction guess
if c_guess==0 && strcmp(strength,'c')==1
c_inc=4*thick;
c_guess=0;    
else
c_inc=1*c_guess;
c_guess=0.0*c_guess;
end

if c_inc==0
    c_inc=0.25*thick;
end

Slope(isnan(Slope))=0;
SlopeSurf(isnan(SlopeSurf))=0;
Aspect(isnan(Aspect))=0;
asp0=mean(Aspect.*bool,'all','omitnan');

%Get Relevant Cells and Weights
idx=find(bool==1);
Slope=Slope(idx);
SlopeSurf=SlopeSurf(idx);
Aspect=Aspect(idx);
W0=dem(idx)-dem_ss(idx); W0(isnan(W0))=0; W0(W0<0)=0;
u0=(dem(idx)-gwdepth-dem_ss(idx)).*(cosd(SlopeSurf)); 
u0(isnan(u0))=0; u0(u0<0)=0;
bool=bool(idx);
kx=0; ky=0; Ex=0; Ey=0;
u=u0.*62.4;
%u=0;

phi_guess(isnan(phi_guess))=0;
c_guess(isnan(c_guess))=0;


  
    
if root_reinforcement==0
    root_cohesion=0;
    
j=1;
% for asp=[asp0-60 asp0 asp0+60]
for asp=asp0-90:45:asp0+90
    
    
    [rotf, phi_j, c_j, iter, ppf, cpf] = SimpJanbu3D_v2_roots(bool, cellsize, Slope, Aspect, asp, c_guess, phi_guess, W0, u, gs, strength, kx, ky, Ex, Ey, c_inc, iter_lim,root_cohesion,root_depth);

    %toc

    if strcmp(strength,'phi')==1 & phi_j>0
    
    p(1,j)=phi_j;
    c(1,j)=c_j;
    break
    
    elseif strcmp(strength,'c')==1 & c_j>0
    
    p(1,j)=phi_j;
    c(1,j)=c_j;    
    break
    
    else
    p(1,j)=NaN;
    c(1,j)=NaN;   
    end
    
    j=j+1;
end

else 
    
    root_cohesion=root_val*20.88;
    %root_depth=3.28;
    
j=1;
% for asp=[asp0-60 asp0 asp0+60]
for asp=asp0-90:45:asp0+90

    
    [rotf, phi_j, c_j, iter, ppf, cpf] = SimpJanbu3D_v2_roots(bool, cellsize, Slope, Aspect, asp, c_guess, phi_guess, W0, u, gs, strength, kx, ky, Ex, Ey, c_inc, iter_lim,root_cohesion,root_depth);

    %toc

    if strcmp(strength,'phi')==1 & phi_j>0
    
    p(1,j)=phi_j;
    c(1,j)=c_j;
    break
    
    elseif strcmp(strength,'c')==1 & c_j>0
    
    p(1,j)=phi_j;
    c(1,j)=c_j;    
    break
    
    else
    p(1,j)=NaN;
    c(1,j)=NaN;   
    end
    
    j=j+1;
end   
    
    
end
    
    
    
phif=max(p,[],'omitnan');
cf=max(c,[],'omitnan');
thickf=mean(W0);
uf=mean(u0);
areaf=sum(bool).*cellsize.*cellsize;
volf=sum(W0.*cellsize.*cellsize);
slopef=mean(SlopeSurf,'omitnan');
medslopef=median(SlopeSurf,'omitnan');
slopessf=mean(Slope,'omitnan');


111;